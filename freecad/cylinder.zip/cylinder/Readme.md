# Hello world cylinder

An example of a machine that just create a cylinder from the __diameter__ and __height__ parameters

This example is intended for learning how to build simple parameterized objects very easily.  Then default cylinder is created as a freecad project. The cylinder.py script opens the document (cylinder.fcstd), get the cylinder, set their parameters and exports to stl
